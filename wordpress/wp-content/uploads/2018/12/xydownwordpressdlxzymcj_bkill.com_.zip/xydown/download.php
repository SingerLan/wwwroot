<?php
require( dirname(__FILE__) . '/wp-load.php' );
$id=$_GET['id'];
$title = get_post($id)->post_title;
$xydown_name=get_post_meta($id, 'xydown_name', true);
$xydown_size=get_post_meta($id, 'xydown_size', true);
$xydown_date=get_post_meta($id, 'xydown_date', true);
$xydown_version=get_post_meta($id, 'xydown_version', true);
$xydown_author=get_post_meta($id, 'xydown_author', true);
$xydown_downurl1=get_post_meta($id, 'xydown_downurl1', true);
$xydown_downurl2=get_post_meta($id, 'xydown_downurl2', true);
$xydown_downurl3=get_post_meta($id, 'xydown_downurl3', true);
$xydown_downurl4=get_post_meta($id, 'xydown_downurl4', true);
$xydown_downurl5=get_post_meta($id, 'xydown_downurl5', true);
$xydown_downurl6=get_post_meta($id, 'xydown_downurl6', true);
$xydown_downurl7=get_post_meta($id, 'xydown_downurl7', true);
$xydown_baidumima=get_post_meta($id, 'xydown_baidumima', true);
$xydown_360mima=get_post_meta($id, 'xydown_360mima', true);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo dirname('http://'.$_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"]); ?>/wp-content/plugins/xydown/css/download.css" />
<title><?php echo $title;?> | 下载页面</title>
<meta name="keywords" content="<?php echo $title;?>" />
<meta name="description" content="<?php echo $title;?>下载" />
</head>
<body>
<div id="header">
	
</div>
<!--广告代码开始-->
<div class="baidu_ad728">
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script><div id="BAIDU_DUP_wrapper_u1534620_0"><iframe width="728" height="90" align="center,center" id="cproIframe_u1534620_4" src="http://pos.baidu.com/acom?adn=3&amp;at=134&amp;aurl=&amp;cad=1&amp;ccd=24&amp;cec=utf-8&amp;cfv=0&amp;ch=0&amp;col=zh-CN&amp;conOP=0&amp;cpa=1&amp;dai=4&amp;dis=0&amp;layout_filter=rank%2Ctabcloud&amp;ltr=&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;lunum=6&amp;n=27043069_cpr&amp;pcs=1920x445&amp;pis=10000x10000&amp;ps=1020x596&amp;psr=1920x1080&amp;pss=1920x1206&amp;qn=336ad31d3f94faa0&amp;rad=&amp;rsi0=728&amp;rsi1=90&amp;rsi5=4&amp;rss0=%23FFFFFF&amp;rss1=%23FFFFFF&amp;rss2=%230000FF&amp;rss3=%23444444&amp;rss4=%23008000&amp;rss5=&amp;rss6=%23e10900&amp;rss7=&amp;scale=&amp;skin=&amp;td_id=1534620&amp;tn=text_default_728_90&amp;tpr=1432172251201&amp;ts=1&amp;version=2.0&amp;xuanting=0&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dc=2&amp;di=u1534620&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;tt=1432172251194.387.629.629" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="true"></iframe></div><script src="http://pos.baidu.com/acom?di=u1534620&amp;dcb=BAIDU_DUP2_define&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dbv=0&amp;dci=0&amp;dri=0&amp;dis=0&amp;dai=4&amp;dds=&amp;drs=1&amp;dvi=1432002453&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;liu=&amp;ltr=&amp;lcr=&amp;ps=1020x596&amp;psr=1920x1080&amp;par=1920x1040&amp;pcs=1920x445&amp;pss=1920x1206&amp;pis=-1x-1&amp;cfv=0&amp;ccd=24&amp;chi=2&amp;cja=true&amp;cpl=0&amp;cmi=0&amp;cce=true&amp;col=zh-CN&amp;cec=utf-8&amp;cdo=-1&amp;tsr=385&amp;tlm=1432172251&amp;tcn=1432172252&amp;tpr=1432172251201&amp;dpt=none&amp;coa=&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;baidu_id=" charset="utf-8"></script>
</div>
<!--广告代码结束-->
<center><h3><a href="<?php echo get_permalink( $id ); ?> ">去《<?php echo get_bloginfo( 'name' ); ?>》看看关于《<?php echo $title;?>》的详细介绍文章 >></a></h3></center>
<div class="download"><p>本站所刊载内容均为网络上收集整理，并且以计算机技术研究交流为目的，所有仅供大家参考、学习，不存在任何商业目的与商业用途。若您需要使用非免费的软件或服务，您应当购买正版授权并合法使用。如果你下载此文件，表示您同意只将此文件用于参考、学习使用而非任何其他用途。</p>
</div>
<!--广告代码开始-->
<div class="baidu_ad728">
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script><div id="BAIDU_DUP_wrapper_u1534620_0"><iframe width="728" height="90" align="center,center" id="cproIframe_u1534620_4" src="http://pos.baidu.com/acom?adn=3&amp;at=134&amp;aurl=&amp;cad=1&amp;ccd=24&amp;cec=utf-8&amp;cfv=0&amp;ch=0&amp;col=zh-CN&amp;conOP=0&amp;cpa=1&amp;dai=4&amp;dis=0&amp;layout_filter=rank%2Ctabcloud&amp;ltr=&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;lunum=6&amp;n=27043069_cpr&amp;pcs=1920x445&amp;pis=10000x10000&amp;ps=1020x596&amp;psr=1920x1080&amp;pss=1920x1206&amp;qn=336ad31d3f94faa0&amp;rad=&amp;rsi0=728&amp;rsi1=90&amp;rsi5=4&amp;rss0=%23FFFFFF&amp;rss1=%23FFFFFF&amp;rss2=%230000FF&amp;rss3=%23444444&amp;rss4=%23008000&amp;rss5=&amp;rss6=%23e10900&amp;rss7=&amp;scale=&amp;skin=&amp;td_id=1534620&amp;tn=text_default_728_90&amp;tpr=1432172251201&amp;ts=1&amp;version=2.0&amp;xuanting=0&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dc=2&amp;di=u1534620&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;tt=1432172251194.387.629.629" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="true"></iframe></div><script src="http://pos.baidu.com/acom?di=u1534620&amp;dcb=BAIDU_DUP2_define&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dbv=0&amp;dci=0&amp;dri=0&amp;dis=0&amp;dai=4&amp;dds=&amp;drs=1&amp;dvi=1432002453&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;liu=&amp;ltr=&amp;lcr=&amp;ps=1020x596&amp;psr=1920x1080&amp;par=1920x1040&amp;pcs=1920x445&amp;pss=1920x1206&amp;pis=-1x-1&amp;cfv=0&amp;ccd=24&amp;chi=2&amp;cja=true&amp;cpl=0&amp;cmi=0&amp;cce=true&amp;col=zh-CN&amp;cec=utf-8&amp;cdo=-1&amp;tsr=385&amp;tlm=1432172251&amp;tcn=1432172252&amp;tpr=1432172251201&amp;dpt=none&amp;coa=&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;baidu_id=" charset="utf-8"></script>
</div>
<!--广告代码结束-->
<div class="download">
  <div class="download-title"><span> 文件信息：</span></div>
  <div class="download-text">
  		<span>文件名称：</span><?php echo $xydown_name;?><br>
		<span>文件大小：</span><?php echo $xydown_size;?><br>
		<span>更新时间：</span><?php echo $xydown_date;?><br>
		<span>作者信息：</span><?php echo $xydown_author;?><br>
		<div class="list"><span>下载地址：</span>
		<?php if($xydown_downurl1){?><a href="<?php echo $xydown_downurl1;?>" target="_blank">百度网盘&nbsp;<font color="red">(<?php if($xydown_baidumima){?>提取码:<?php echo $xydown_baidumima; }?>)</font></a><?php } if($xydown_downurl4){?><a href="<?php echo $xydown_downurl4;?>" target="_blank">迅雷快传</a><?php }if($xydown_downurl5){?><a href="<?php echo $xydown_downurl5;?>" target="_blank">360网盘&nbsp;<font color="red">(<?php if($xydown_360mima){?>提取码:<?php echo $xydown_360mima;?>)</font><?php }?></a><?php }if($xydown_downurl6){?><a href="<?php echo $xydown_downurl6;?>" target="_blank">其他网盘</a><?php }if($xydown_downurl7){?><a href="<?php echo $xydown_downurl7;?>" target="_blank">官方下载</a><?php }if($xydown_downurl2){?><a href="<?php echo $xydown_downurl2;?>" target="_blank">城通网盘</a><?php } if($xydown_downurl3){?><a href="<?php echo $xydown_downurl3;?>" target="_blank"><font color="red">普通下载</font></a><?php }?><br>
		</div></div>
  </div>
</div>
<!--广告代码开始-->
<div class="baidu_ad728">
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script><div id="BAIDU_DUP_wrapper_u1534620_0"><iframe width="728" height="90" align="center,center" id="cproIframe_u1534620_4" src="http://pos.baidu.com/acom?adn=3&amp;at=134&amp;aurl=&amp;cad=1&amp;ccd=24&amp;cec=utf-8&amp;cfv=0&amp;ch=0&amp;col=zh-CN&amp;conOP=0&amp;cpa=1&amp;dai=4&amp;dis=0&amp;layout_filter=rank%2Ctabcloud&amp;ltr=&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;lunum=6&amp;n=27043069_cpr&amp;pcs=1920x445&amp;pis=10000x10000&amp;ps=1020x596&amp;psr=1920x1080&amp;pss=1920x1206&amp;qn=336ad31d3f94faa0&amp;rad=&amp;rsi0=728&amp;rsi1=90&amp;rsi5=4&amp;rss0=%23FFFFFF&amp;rss1=%23FFFFFF&amp;rss2=%230000FF&amp;rss3=%23444444&amp;rss4=%23008000&amp;rss5=&amp;rss6=%23e10900&amp;rss7=&amp;scale=&amp;skin=&amp;td_id=1534620&amp;tn=text_default_728_90&amp;tpr=1432172251201&amp;ts=1&amp;version=2.0&amp;xuanting=0&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dc=2&amp;di=u1534620&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;tt=1432172251194.387.629.629" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="true"></iframe></div><script src="http://pos.baidu.com/acom?di=u1534620&amp;dcb=BAIDU_DUP2_define&amp;dtm=BAIDU_DUP2_SETJSONADSLOT&amp;dbv=0&amp;dci=0&amp;dri=0&amp;dis=0&amp;dai=4&amp;dds=&amp;drs=1&amp;dvi=1432002453&amp;ltu=http%3A%2F%2Fwenchenhk.com%2Fdl%2Ffrontopen.html&amp;liu=&amp;ltr=&amp;lcr=&amp;ps=1020x596&amp;psr=1920x1080&amp;par=1920x1040&amp;pcs=1920x445&amp;pss=1920x1206&amp;pis=-1x-1&amp;cfv=0&amp;ccd=24&amp;chi=2&amp;cja=true&amp;cpl=0&amp;cmi=0&amp;cce=true&amp;col=zh-CN&amp;cec=utf-8&amp;cdo=-1&amp;tsr=385&amp;tlm=1432172251&amp;tcn=1432172252&amp;tpr=1432172251201&amp;dpt=none&amp;coa=&amp;ti=wordpress%E4%B8%BB%E9%A2%98%EF%BC%9A%E5%9B%BD%E4%BA%BA%E5%8E%9F%E5%88%9B%E6%89%81%E5%B9%B3%E5%8C%96%E8%AE%BE%E8%AE%A1frontopen%E4%B8%BB%E9%A2%98%20%7C%20%E6%9A%97%E6%B7%A1%E7%9A%84%E9%BB%91IT%E7%BD%91%E7%BB%9C&amp;baidu_id=" charset="utf-8"></script>
</div>
<!--广告代码结束-->
<div class="download">
<p>1.如果您发现本资源下载地址已经失效不能下载，请联系站长修正下载链接！</p>
<p>2.如无特殊说明,本站统一解压密码为:www.52-zyw.com.</p>
</div>

<div class="clear"></div>

<div class="copy" style="text-align: center;margin-top:15px;">
	Copyright © 2014-2015 <a href="http://www.52-zyw.com">我爱资源网</a> 版权所有. 
</div>

</body>
</html>